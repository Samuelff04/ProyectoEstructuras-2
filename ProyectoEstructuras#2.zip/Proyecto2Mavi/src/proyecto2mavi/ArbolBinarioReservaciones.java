/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto2mavi;

public class ArbolBinarioReservaciones {

    public Reservacion raiz;

    public ArbolBinarioReservaciones() {
        this.raiz = null;
    }

    public void nuevaReservacion(int ci, String primer_nombre, String segundo_nombre, String email, String genero, String tipo_hab, String celular, String fecha_llegada, String fecha_salida) {
        Reservacion nueva = new Reservacion(ci, primer_nombre, segundo_nombre, email, genero, tipo_hab, celular, fecha_llegada, fecha_salida);
        if (this.raiz == null) {
            this.raiz = nueva;
        } else {
            this.InsertarReserva(nueva, this.raiz);
            this.ReEstructurarArbol(this.raiz);
        }
    }

    public void InsertarReserva(Reservacion nueva, Reservacion padre) {
        if (padre != null) {
            if (padre.getCi() >= nueva.getCi()) {
                if (padre.getHijoIzquierdo() != null) {
                    this.InsertarReserva(nueva, padre.getHijoIzquierdo());
                } else {
                    padre.setHijoIzquierdo(nueva);
                }
            } else if (padre.getCi() < nueva.getCi()) {
                if (padre.getHijoDerecho() != null) {
                    this.InsertarReserva(nueva, padre.getHijoDerecho());
                } else {
                    padre.setHijoDerecho(nueva);
                }
            }
        }
    }

    public Reservacion buscarReserva(int ci, Reservacion padre) {
        if (padre != null) {
            Reservacion buscar = null;
            if (padre.getCi() > ci) {
                buscar = this.buscarReserva(ci, padre.getHijoIzquierdo());
            } else if (padre.getCi() < ci) {
                buscar = this.buscarReserva(ci, padre.getHijoDerecho());
            } else {
                return padre;
            }
            return buscar;
        }
        return null;
    }

    public int height(Reservacion node) {
        if (node == null) {
            return 0;
        }
        return node.height;
    }

    public int max(int a, int b) {
        return (a > b) ? a : b;
    }

//    public Reservacion newNode(int ci, String primer_nombre, String segundo_nombre, String email, String genero, String tipo_hab, String celular, String fecha_llegada, String fecha_salida) {
//        Reservacion node = new Reservacion(ci, primer_nombre, segundo_nombre, email, genero, tipo_hab, celular, fecha_llegada, fecha_salida);
//        node.height = 1;
//        node.hijoIzquierdo = null;
//        node.hijoDerecho = null;
//        return node;
//    }
    public Reservacion RotarHijoDerecho(Reservacion y) {
        Reservacion x = y.getHijoIzquierdo();
        Reservacion aux = x.getHijoDerecho();

        x.setHijoDerecho(y);
        y.setHijoIzquierdo(aux);

        y.height = this.max(this.height(y.getHijoIzquierdo()), this.height(y.getHijoDerecho())) + 1;
        x.height = this.max(this.height(x.getHijoIzquierdo()), this.height(x.getHijoDerecho())) + 1;

        return x;
    }

    public Reservacion RotarHijoIzquierdo(Reservacion x) {
        Reservacion y = x.getHijoDerecho();
        Reservacion aux = y.getHijoIzquierdo();

        y.setHijoIzquierdo(x);
        x.setHijoDerecho(aux);

        x.height = this.max(this.height(x.getHijoIzquierdo()), this.height(x.getHijoDerecho())) + 1;
        y.height = this.max(this.height(y.getHijoIzquierdo()), this.height(y.getHijoDerecho())) + 1;

        return y;
    }

    public int Balance(Reservacion N) {
        if (N == null) {
            return 0;
        }
        return this.height(N.getHijoIzquierdo()) - this.height(N.getHijoDerecho());
    }

    public Reservacion ReEstructurarArbol(Reservacion reservaActual) {
        if (reservaActual == null) {
            return reservaActual;
        }

        if (this.Balance(reservaActual) == 2) {
            if (this.Balance(reservaActual.getHijoIzquierdo()) < 0) {
                reservaActual.setHijoIzquierdo(this.RotarHijoIzquierdo(reservaActual.getHijoIzquierdo()));
            }
            reservaActual = this.RotarHijoDerecho(reservaActual);
        } else if (this.Balance(reservaActual) == -2) {
            if (this.Balance(reservaActual.getHijoDerecho()) > 0) {
                reservaActual.setHijoDerecho(this.RotarHijoDerecho(reservaActual.getHijoDerecho()));
            }
            reservaActual = this.RotarHijoIzquierdo(reservaActual);
        }

        reservaActual.height = this.max(this.height(reservaActual.getHijoIzquierdo()), this.height(reservaActual.getHijoDerecho())) + 1;

        return reservaActual;
    }

    public String imprimir(Reservacion actual, String txt) {
        if (actual != null) {
            txt = this.imprimir(actual.getHijoIzquierdo(), txt);
            txt += actual.getCi() + "; ";
            txt = this.imprimir(actual.getHijoDerecho(), txt);

        }
        return txt;
    }

    public void EliminarReservacion(int ci) {
        this.raiz = Eliminar(this.raiz, ci);
    }

    private Reservacion Eliminar(Reservacion reservaActual, int ci) {
        if (reservaActual == null) {
            return null;
        }

        if (ci < reservaActual.getCi()) {
            reservaActual.setHijoIzquierdo(Eliminar(reservaActual.getHijoIzquierdo(), ci));
        } else if (ci > reservaActual.getCi()) {
            reservaActual.setHijoDerecho(Eliminar(reservaActual.getHijoDerecho(), ci));
        } else {
            if (reservaActual.getHijoIzquierdo() == null && reservaActual.getHijoDerecho() == null) {
                reservaActual = null;
            } else if (reservaActual.getHijoIzquierdo() == null) {
                reservaActual = reservaActual.getHijoDerecho();
            } else if (reservaActual.getHijoDerecho() == null) {
                reservaActual = reservaActual.getHijoIzquierdo();
            } else {
                Reservacion reservaMinima = buscarMinReserva(reservaActual.getHijoDerecho());
                reservaActual.setCi(reservaMinima.getCi());
                reservaActual.setHijoDerecho(Eliminar(reservaActual.getHijoDerecho(), reservaMinima.getCi()));
            }
        }

        if (reservaActual != null) {
            reservaActual.height = 1 + Math.max(height(reservaActual.getHijoIzquierdo()), height(reservaActual.getHijoDerecho()));
            int balance = height(reservaActual.getHijoIzquierdo()) - height(reservaActual.getHijoDerecho());

            if (balance > 1 && height(reservaActual.getHijoIzquierdo().getHijoIzquierdo()) >= height(reservaActual.getHijoIzquierdo().getHijoDerecho())) {
                reservaActual = RotarHijoDerecho(reservaActual);
            } else if (balance > 1 && height(reservaActual.getHijoIzquierdo().getHijoDerecho()) > height(reservaActual.getHijoIzquierdo().getHijoIzquierdo())) {
                reservaActual.setHijoIzquierdo(RotarHijoIzquierdo(reservaActual.getHijoIzquierdo()));
                reservaActual = RotarHijoDerecho(reservaActual);
            } else if (balance < -1 && height(reservaActual.getHijoDerecho().getHijoDerecho()) >= height(reservaActual.getHijoDerecho().getHijoIzquierdo())) {
                reservaActual = RotarHijoIzquierdo(reservaActual);
            } else if (balance < -1 && height(reservaActual.getHijoDerecho().getHijoIzquierdo()) > height(reservaActual.getHijoDerecho().getHijoDerecho())) {
                reservaActual.setHijoDerecho(RotarHijoDerecho(reservaActual.getHijoDerecho()));
                reservaActual = RotarHijoIzquierdo(reservaActual);
            }
        }

        return reservaActual;
    }

    private Reservacion buscarMinReserva(Reservacion reservaActual) {
        if (reservaActual.getHijoIzquierdo() == null) {
            return reservaActual;
        }
        return buscarMinReserva(reservaActual.getHijoIzquierdo());
    }
}
