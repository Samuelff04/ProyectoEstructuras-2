/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto2mavi;

public class ListaHuespedes {

    NodoCliente primero;

    public ListaHuespedes() {
        this.primero = null;
    }

    public void insertar(NodoCliente nuevo) {
        if (this.primero == null) {
            this.primero = nuevo;
        } else {
            nuevo.setpNext(this.primero);
            this.primero = nuevo;
        }
    }

    public NodoCliente buscar(String nombre, String apellido) {
        if (this.primero == null) {
            return null;
        } else {
            NodoCliente auxiliar = this.primero;
            while (auxiliar != null && !auxiliar.getNombre().equals(nombre) && !auxiliar.getApellido().equals(apellido)) {
                auxiliar = auxiliar.getpNext();
            }
            return auxiliar;
        }
    }

    public void eliminar(String nombre, String apellido) {
        if (this.primero != null) {
            NodoCliente auxiliar = this.primero;
            if (auxiliar.getNombre().equals(nombre) && auxiliar.getApellido().equals(apellido)) {
                this.primero = this.primero.getpNext();
            } else {
                while (auxiliar.getpNext() != null && !auxiliar.getpNext().getNombre().equals(nombre) && !auxiliar.getpNext().getApellido().equals(apellido)) {
                    auxiliar = auxiliar.getpNext();
                }
                if (auxiliar.getpNext() != null) {
                    auxiliar.setpNext(auxiliar.getpNext().getpNext());
                }
            }
        }

    }
}
