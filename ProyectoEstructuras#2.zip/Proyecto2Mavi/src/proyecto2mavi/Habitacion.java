/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto2mavi;


public class Habitacion {
   int numero_hab;
   int piso;
   String tipo;
   HistorialHabitacion raiz;
   boolean ocupada;

    public Habitacion(int numero_hab, int piso, String tipo) {
        this.numero_hab = numero_hab;
        this.piso = piso;
        this.tipo = tipo;
        this.raiz = null;
        ocupada = false;
    }
    
    public void añadirHistorial(int ci, String nombre, String apellido, String email, String genero, String llegada){
        HistorialHabitacion historial = new HistorialHabitacion(ci,nombre,apellido,email,genero,llegada);
        if(this.raiz == null){
            this.raiz = historial;
        }else{
            this.insertarHistorial(historial, this.raiz);
        }
    }
    
    public void insertarHistorial(HistorialHabitacion nueva, HistorialHabitacion padre) {
        if (padre != null) {
            if (padre.getCi() >= nueva.getCi()) {
                if (padre.getHijoIzquierdo() != null) {
                    this.insertarHistorial(nueva, padre.getHijoIzquierdo());
                } else {
                    padre.setHijoIzquierdo(nueva);
                }
            } else if (padre.getCi() < nueva.getCi()) {
                if (padre.getHijoDerecho() != null) {
                    this.insertarHistorial(nueva, padre.getHijoDerecho());
                } else {
                    padre.setHijoDerecho(nueva);
                }
            }
        }
    }

    public int height(HistorialHabitacion node) {
        if (node == null) {
            return 0;
        }
        return node.height;
    }

    public int max(int a, int b) {
        return (a > b) ? a : b;
    }

//    public Reservacion newNode(int ci, String primer_nombre, String segundo_nombre, String email, String genero, String tipo_hab, String celular, String fecha_llegada, String fecha_salida) {
//        Reservacion node = new Reservacion(ci, primer_nombre, segundo_nombre, email, genero, tipo_hab, celular, fecha_llegada, fecha_salida);
//        node.height = 1;
//        node.hijoIzquierdo = null;
//        node.hijoDerecho = null;
//        return node;
//    }
    public HistorialHabitacion RotarHijoDerecho(HistorialHabitacion y) {
        HistorialHabitacion x = y.getHijoIzquierdo();
        HistorialHabitacion aux = x.getHijoDerecho();

        x.setHijoDerecho(y);
        y.setHijoIzquierdo(aux);

        y.height = this.max(this.height(y.getHijoIzquierdo()), this.height(y.getHijoDerecho())) + 1;
        x.height = this.max(this.height(x.getHijoIzquierdo()), this.height(x.getHijoDerecho())) + 1;

        return x;
    }

    public HistorialHabitacion RotarHijoIzquierdo(HistorialHabitacion x) {
        HistorialHabitacion y = x.getHijoDerecho();
        HistorialHabitacion aux = y.getHijoIzquierdo();

        y.setHijoIzquierdo(x);
        x.setHijoDerecho(aux);

        x.height = this.max(this.height(x.getHijoIzquierdo()), this.height(x.getHijoDerecho())) + 1;
        y.height = this.max(this.height(y.getHijoIzquierdo()), this.height(y.getHijoDerecho())) + 1;

        return y;
    }

    public int Balance(HistorialHabitacion N) {
        if (N == null) {
            return 0;
        }
        return this.height(N.getHijoIzquierdo()) - this.height(N.getHijoDerecho());
    }

    public HistorialHabitacion ReEstructurarArbol(HistorialHabitacion reservaActual) {
        if (reservaActual == null) {
            return reservaActual;
        }

        if (this.Balance(reservaActual) == 2) {
            if (this.Balance(reservaActual.getHijoIzquierdo()) < 0) {
                reservaActual.setHijoIzquierdo(this.RotarHijoIzquierdo(reservaActual.getHijoIzquierdo()));
            }
            reservaActual = this.RotarHijoDerecho(reservaActual);
        } else if (this.Balance(reservaActual) == -2) {
            if (this.Balance(reservaActual.getHijoDerecho()) > 0) {
                reservaActual.setHijoDerecho(this.RotarHijoDerecho(reservaActual.getHijoDerecho()));
            }
            reservaActual = this.RotarHijoIzquierdo(reservaActual);
        }

        reservaActual.height = this.max(this.height(reservaActual.getHijoIzquierdo()), this.height(reservaActual.getHijoDerecho())) + 1;

        return reservaActual;
    }

    public String imprimir(HistorialHabitacion actual, String txt) {
        if (actual != null) {
            txt = this.imprimir(actual.getHijoIzquierdo(), txt);
            txt += actual.mostrar() + "\n";
            txt = this.imprimir(actual.getHijoDerecho(), txt);

        }
        return txt;
    }
   
   
}
