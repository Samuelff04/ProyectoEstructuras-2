/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto2mavi;


public class Proyecto2Mavi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
//        RegistroHash r = new RegistroHash();
//        r.insertar("andres", "sdfsd", 56);
//        r.insertar("sdfdsfdsf", "feger", 87);
//        r.insertar("anxcbxcbdres", "sdgfdfdfsd", 54);
//        r.insertar("andrgregaes", "sdf7yijsd", 12);
//        r.insertar("andr4t346t3es", "fghr", 43);
//        r.insertar("andragagaeaeregareges", "4325gfd", 2);
//        BusquedaHuespedes bh = new BusquedaHuespedes(r);
//        bh.setVisible(true);
//
//
//
//        ArbolBinarioReservaciones abr = new ArbolBinarioReservaciones();
//        abr.nuevaReservacion(456, "dsfs", "sfdaf", "fdñiligjdlf", "hrt", "uyt", "uyt", "dfGDFGD", "fddgDFgf");
//        abr.nuevaReservacion(45645, "dvfh", "sdsdgg", "goashosd", "h", "ewt", "TGHDGF", "ouiu", "lhjk");
//        abr.nuevaReservacion(78, "vnxcvnx", "sfdauyf", "j5ewujh", "jyt", "SDwetFasf", "luil", "ryrhf", "hjllrr");
//        abr.nuevaReservacion(454, ",ylyu", "6433", "gaerhratj", "546", "SDetFasf", "asdsa", "jyk", "liihsdl");
//        abr.nuevaReservacion(123, "jtyjklk", "yerhfd", "aheraererf", "jt", "i67", "TGHDGadsadF", "shhgykfggf", "liuutru");
//        abr.nuevaReservacion(543, "kghhd", "gfhfgj", "fadhdfadf", "hgf", "rui7", "khjjkh", "dfhrehbaehrareGDFGD", "ourwolg");
//        abr.nuevaReservacion(57, "dfil", "kyttktu", "5ii7", "SDFdf", "hgf", "hdjhd", "ehaeh ", "vlnnoav");
//        abr.nuevaReservacion(654, "rpñeoighaliksj", "ktswry", "regseh", "gdfh", "SDFasf", "jdhgd", "bn antr", "vovsjpsoidhv");
//        Hotel h = new Hotel();
//        
//        BusquedaReservacion br = new BusquedaReservacion(h);
//        br.setVisible(true);
//        System.out.println(abr.imprimir(abr.raiz, ""));
//        abr.EliminarReservacion(45645);
//        System.out.println(abr.imprimir(abr.raiz, ""));
//        abr.EliminarReservacion(454);
//        System.out.println(abr.imprimir(abr.raiz, ""));
            Hotel h = new Hotel();
            MenuHotel mh = new MenuHotel(h);


    }
    
}
